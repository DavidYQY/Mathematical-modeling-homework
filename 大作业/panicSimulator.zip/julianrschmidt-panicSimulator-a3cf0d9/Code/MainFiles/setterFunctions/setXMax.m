function [ settings ] = setXMax( settings, xMax )
%SETXMAX changes xMax to desired value
settings.xMax = xMax;

end

