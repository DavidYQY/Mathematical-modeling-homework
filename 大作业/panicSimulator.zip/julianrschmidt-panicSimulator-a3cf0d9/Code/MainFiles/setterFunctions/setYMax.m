function [ settings ] = setYMax( settings, yMax )
%SETXMAX changes yMax to desired value
settings.yMax = yMax;
end

